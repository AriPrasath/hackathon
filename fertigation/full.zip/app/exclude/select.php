
<html lang="en">
    <head>
	  <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="Vikkey" content="Vivek Gupta & IoTMonk">
	  <meta http-equiv="Access-Control-Allow-Origin" content="*">

	<!--
	 <script type="text/javascript">
		document.write([
			"\<script src='",
			("https:" == document.location.protocol) ? "https://" : "http://",
			"ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js' type='text/javascript'>\<\/script>" 
		].join(''));
	  </script>
	  -->
	
      <title>FERTIGATION</title>
        <style>

	.footer{
		background:#c5d5cb;
		width:100%;
		height:100px;
		position:absolute;
		bottom:0;
		left:0;
	}

	select {
		background-color:#e3e0cf;
		width:200px;
		padding:12px;
		margin-top:8px;
		line-height:1;
		color:black;
		border-radius:5px;
		font-size:16px;
		-webkit-appearance:none;
		box-shadow:inset 0 0 10px 0 rgba(0,0,0,0.6);
		outline:none
	}
	select:hover {
	}


    .center { 
		height: 550px;
		width: 500px;
		background-color:#9fa8a3;
		position:fixed;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
		top: 30%;
		left: 50%;
		margin-top: -120px;
		margin-left: -250px;
	}
	
	.form{
		padding-top: 10px;
		padding-right: 30px;
		padding-bottom: 50px;
		padding-left: 30px;
	}
    .ip{
		background-color: #ffffff; /* Green */
		border: none;
		color: black;
		padding: 16px 32px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
		margin: 4px 2px;
		-webkit-transition-duration: 0.4s; /* Safari */
    }
        </style>
    </head>


   <body bgcolor=#e3e0cf>
    <center>
        <h1 style="font-family: Helvetica;color: black;">AUTOMATIC FERTIGATION SYSTEM </h1>
    </center>
	
	<div class="center">
	   <div align="center" class="form">
	   <h3>SELECT YOUR CROP</h3>
           <br><br>
		   <!--
            <p style = 'line-height: 60px;font-family: Helvetica;color: #fff;font-size: 50px;' id="temperature">
                <img src = 'humidity.png' height="60px" width="60px" style='vertical-align: middle' /> 01.00
            </p>

			<p style = 'line-height: 60px;font-family: Helvetica;color: #fff;font-size: 50px;' id="status">
                <img src = 'status.png' height="60px" width="60px" style='vertical-align: middle' /> ON
			</p>
			-->

			<div class="dropdown">
				<form action="selected.php" method="POST">
  					<select name="sel" >
    						<option value="1" >TOMATO</option>
    						<option value="7" >POTATO</option>
    						<option value="2" >CHILLY</option>
						<option value="4">SUGERCANE</option>
    						<option value="3">BEANS</option>
    						<option value="5">BRINJAL</option>
						<option value="6">CORRIANDER</option>
						<br>
						<br>
						
						<input type="submit">
						
					</select>
				</form>
				
     

</div>
	<footer class="footer">
		<center>
			<h4 style="font-family: Helvetica;color:black;">&copy; 2019 | <a href="">fertigation</a> | <a href="">CSE</a> </h4>
		</center>
	</footer>

    </body>
	
	
</html>
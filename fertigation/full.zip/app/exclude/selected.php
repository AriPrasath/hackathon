<?php 
	session_start();
?>

<!DOCTYPE html>

<html lang="en">
    <head>
	  <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta name="Vikkey" content="Vivek Gupta & IoTMonk">
	  <meta http-equiv="Access-Control-Allow-Origin" content="*">

	 <script type="text/javascript">
		document.write([
			"\<script src='",
			("https:" == document.location.protocol) ? "https://" : "http://",
			"ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js' type='text/javascript'>\<\/script>" 
		].join(''));
	  </script>
	
      <title>SELECTED VALUES</title>
        <style>

	.footer{
		background:#64B5F6;
		width:100%;
		height:100px;
		position:absolute;
		bottom:0;
		left:0;
	}

    .center { 
		height: 400px;
		width: 400px;
		background: #c0c5ce;
		position: fixed;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
		top: 50%;
		left: 50%;
		margin-top: -180px;
		margin-left: -200px;
	}
	
	.form{
		padding-top: 10px;
		padding-right: 30px;
		padding-bottom: 50px;
		padding-left: 30px;
	}
    .ip{
		background-color: #ffffff; /* Green */
		border: none;
		color: black;
		padding: 16px 32px;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
		margin: 4px 2px;
		-webkit-transition-duration: 0.4s; /* Safari */
    }
        </style>
    </head>


   <body bgcolor="#ffffff">
    <center>
        <h1 style="font-family: Helvetica;color: black;">SELECTED VALUES</h1>
    </center>
	<div class="center">
	   <div align="center" class="form">
           <br><br>
		    <?php echo "crop id".$_POST["sel"];
		    
		    echo "<br>";
		    echo $_SESSION["user"]
		    ?>
		    
		    
		    
		    
         </div>
	</div>

    <?PHP
	$userid=$_SESSION['user'];
	$cropid=$_POST['sel'];
	$new='1';
	if ((!empty($userid)) && (!empty($cropid))){

					$host = "localhost";
					$dbusername = "id10409503_fertigation";
					$dbpassword = "fertigation";
					$dbname = "id10409503_fertigation";
					// Create connection
					$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
					if (mysqli_connect_error()){
						die('Connect Error ('. mysqli_connect_errno() .') '
						. mysqli_connect_error());
					}
					else{
                        $ret=mysqli_query( $conn, "UPDATE usertable SET cropid='$cropid', cstage='$new', cday='$new', snod='$new' WHERE userid='$userid'") or die("Could not execute query: " .mysqli_error($conn));
		               
					$conn->close();
					}	
	}
	else{	
		echo "Username should not be empty";
				die();
	}
	?>
	
	<footer class="footer">
		<center>
			<h4 style="font-family: Helvetica;color: white;">&copy; 2019 | <a href="">fertigation</a> | <a href="">CSE</a> </h4>
		</center>
	</footer>
    
    </body>
      
    
</html>
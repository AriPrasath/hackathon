<?php
//if(isset($_POSt['submit'])){
	$username=$_POST['username1'];
	$password=$_POST['password1'];
	$pass=$_POST['pass1'];
	if (!empty($username)){
		if (!empty($password)){
			if (!empty($pass)){
				if (($password)==($pass)){

					$host = "localhost";
					$dbusername = "id10409503_fertigation";
					$dbpassword = "fertigation";
					$dbname = "id10409503_fertigation";
					// Create connection
					$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
					if (mysqli_connect_error()){
						die('Connect Error ('. mysqli_connect_errno() .') '
						. mysqli_connect_error());
					}
					else{
						$sql = "INSERT INTO user (username, password)
						values ('$username','$password')";
						if ($conn->query($sql)){
							header("location: login page.php");
						}
						else{
							echo "Error: ". $sql ."
							". $conn->error;
						}
					$conn->close();
					}
				}
				else{
					echo "Password should  be equal";
					die();
				}
			}else{
				echo "Confirm Password should not be empty";
				die();
			}
		}
		else{
			echo "Password should not be empty";
			die();
		}	
	}
	else{	
		echo "Username should not be empty";
				die();
	}
//}else{
	//echo "no input";
	//die();
//}



?>
<?php

header("Access-Control_Allow_Origin: *");
header("Content-Tyepe: application/jason; charset=UTF-8:");

$response = array();

if(isset($_GET['id'])) {
    $id=$_GET['id'];
    
    
    $filepath = realpath (dirname(__FILE__));
    require_once($filepath."/db_connect.php");
		

	$db = new DB_CONNECT();

	$result=mysql_query("SELECT c.n,c.p,c.k 
    FROM crop c, usertable u 
    WHERE c.cropid=u.cropid AND c.stage=u.cstage AND u.userid='$id'");

	if($result) {

		$response["Success"] = $result;
        echo $result['c.p'];
        echo $result['c.k'];

        $result1=mysql_query("UPDATE usertable SET cday=((SELECT cday FROM usertable WHERE userid='$id')+1) ,snod=(SELECT c.nod  FROM crop c ,usertable u  WHERE u.userid='$id' AND u.cropid=c.cropid AND u.cstage=c.stage) WHERE userid='$id'");

        if($result1){
               $response["success"]=2;
               $response["message"] = "Day updated in db";
        } 
        else {
         
        }
        $r1=mysql_query("SELECT cday 
            FROM usertable 
            WHERE userid=$id 
            ");
        $r2=("select nod 
            FROM crop 
            WHERE userid=$id");
        if($r1>$r2){
            $result2=mysql_query("UPDATE usertable 
            SET cstage=((SELECT cstage FROM usertable WHERE userid='$id')+1) , cday=1
            WHERE userid='$id'
            AND 
            (SELECT cday FROM usertable WHERE userid='$id')>(SELECT snod FROM usertable WHERE userid='$id')");
            
            mysql_query("UPDATE usertable
            SET snod=(SELECT nod FROM crop c ,usertable u WHERE u.userid='$id' AND u.cropid=c.cropid)
            WHERE userid='$id'");
            
            if($result2){
                $response["success"]=3;
                $response["message"] = "Stage updated in db";  
                
                $s1=mysql_query("SELECT cstage 
                    FROM usertable 
                    WHERE userid=$id 
                    ");
                
                $result3=mysql_query("SELECT c.n,c.p,c.k 
                    FROM crop c, usertable u 
                    WHERE c.cropid=u.cropid AND c.stage=u.cstage AND u.userid='$id'");
                

                if(!$result3){
                    
                    header("location: thanks.php");
                
                }
            }
            else{
             $response["message"] = "Stage  update error"; 
         
             }
	    }else{
	        
	    }
		echo json_encode($response);
	} else {

		$response["Success"] = 0;
        $response["message"] = "Something has been wrong";
        echo "0";
        echo "0";
        echo "0";
	

		echo json_encode($response);
	}
}else {

	$response["Success"] = 0;
	$response["message"] = "Parameter (s) are missing . Please check the request";

	echo json_encode($response);
	
}
?>
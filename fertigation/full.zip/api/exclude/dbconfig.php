<?php


define('DB_USER', "id10409503_fertigation");     // Your database user name
define('DB_PASSWORD', "fertigation");			// Your database password (mention your db password here)
define('DB_DATABASE', "id10409503_fertigation"); // Your database name
define('DB_SERVER', "localhost");			// db server (Mostly will be 'local' host)

?>
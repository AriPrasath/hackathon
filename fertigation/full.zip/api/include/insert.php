<?php

header("Access-Control_Allow_Origin: *");
header("Content-Tyepe: application/jason; charset=UTF-8:");

$response = array();

if(isset($_POST['id']) && isset($_POST['temp']) && isset($_POST['status'])) {
    $id=$_POST['id'];
	$temp=$_POST['temp'];
    $status=$_POST['status'];
    
    
$filepath = realpath (dirname(__FILE__));
require_once($filepath."/db_connect.php");
		

	$db = new DB_CONNECT();

	$result=mysql_query("INSERT INTO irrigation(userid,moisture,status)
	VALUES('$id','$temp','$status')");

	if($result) {

		$response["Success"] = 1;
		$response["message"] = "values updated in db";

		echo json_encode($response);
	} else {

		$response["Success"] = 0;
		$response["message"] = "Something has been wrong";

		echo json_encode($response);
	}
}else {

	$response["Success"] = 0;
	$response["message"] = "Parameter (s) are missing . Please check the request";

	echo json_encode($response);
	
}
?>